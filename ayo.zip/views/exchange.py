import os
import json
import random
import asyncio
import discord
import datetime

from utils.stake import Stake
from utils.paypay import PayPay
from views.register import StartRegisterModal

class ExchangeButton(discord.ui.View):
    def __init__(self, cool, config):
        super().__init__(
            timeout=None
        )

        self.cool = cool
        self.config = config

    @discord.ui.button(
        label="チップ換金",
        custom_id="tip_exchange",
        style=discord.ButtonStyle.green
    )
    async def tip_exchange(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if not self.config["ft_enable_tip"]:
            failed_embed = discord.Embed(title="失敗", description="チップ換金の機能は無効にされています。", color=discord.Color.red())
            await interaction.response.send_message(embed=failed_embed, ephemeral=True)
            return

        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)

        if len(cache_data["accounts"]) == 0:
            error_embed = discord.Embed(title="エラー", description="PayPayにログインされていません。", color=discord.Color.red())
            await interaction.response.send_message(embed=error_embed, ephemeral=True)
            return

        max_index = len(cache_data["accounts"]) - 1
        min_index = 0
        acc_index = random.randint(min_index, max_index)
        account_cache = cache_data["accounts"][acc_index]

        paypay = PayPay(account_cache["access_token"], account_cache["device_uuid"], account_cache["client_uuid"])
        stake = Stake(self.config["stake_apikey"], self.config["stake_tfakey"], self.config["stake_ua"], self.config["stake_chua"], self.config["stake_clear"], None if self.config["stake_proxy"] == "" else self.config["stake_proxy"], self.config["ft_enable_debug"])

        with open("./data/paypay.json", "r", encoding="utf-8") as file:
            paypay_data = json.load(file)
        if paypay_data.get(str(interaction.user.id)) == None:
            await interaction.response.send_modal(StartRegisterModal())
        else:
            coro = asyncio.to_thread(stake.get_balance)
            balance = await coro

            coro = asyncio.to_thread(stake.get_rate)
            rate = await coro

            bal = round(balance*rate, 2)

            await interaction.response.send_modal(TipExchangeModal(self.cool, self.config, paypay, stake, bal))

    @discord.ui.button(
        label="アドレス換金",
        custom_id="address_exchange",
        style=discord.ButtonStyle.green
    )
    async def address_exchange(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        if not self.config["ft_enable_address"]:
            failed_embed = discord.Embed(title="失敗", description="アドレス換金の機能は無効にされています。", color=discord.Color.red())
            await interaction.response.send_message(embed=failed_embed, ephemeral=True)
            return

        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)

        if len(cache_data["accounts"]) == 0:
            error_embed = discord.Embed(title="エラー", description="PayPayにログインされていません。", color=discord.Color.red())
            await interaction.response.send_message(embed=error_embed, ephemeral=True)
            return

        max_index = len(cache_data["accounts"]) - 1
        min_index = 0
        acc_index = random.randint(min_index, max_index)
        account_cache = cache_data["accounts"][acc_index]

        paypay = PayPay(account_cache["access_token"], account_cache["device_uuid"], account_cache["client_uuid"])
        stake = Stake(self.config["stake_apikey"], self.config["stake_tfakey"], self.config["stake_ua"], self.config["stake_chua"], self.config["stake_clear"], None if self.config["stake_proxy"] == "" else self.config["stake_proxy"], self.config["ft_enable_debug"])

        with open("./data/paypay.json", "r", encoding="utf-8") as file:
            paypay_data = json.load(file)
        if paypay_data.get(str(interaction.user.id)) == None:
            await interaction.response.send_modal(StartRegisterModal())
        else:
            coro = asyncio.to_thread(stake.get_balance)
            balance = await coro

            coro = asyncio.to_thread(stake.get_rate)
            rate = await coro

            bal = round(balance*rate, 2)

            await interaction.response.send_modal(AddressExchangeModal(self.cool, self.config, paypay, stake, bal))

class TipExchangeModal(discord.ui.Modal):
    def __init__(self, cool, config, paypay, stake, balance):
        super().__init__(
            title=f"残高: {balance}円",
            timeout=None
        )

        self.cool = cool
        self.config = config
        self.paypay = paypay
        self.stake = stake

        self.stake_id = discord.ui.TextInput(
            label="Stake ID",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.stake_id)

        self.paypay_link = discord.ui.TextInput(
            label="PayPay 送金リンク",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.paypay_link)

        self.paypay_passcode = discord.ui.TextInput(
            label="PayPay パスコード",
            style=discord.TextStyle.short,
            min_length=4,
            max_length=4,
            required=False
        )
        self.add_item(self.paypay_passcode)

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        if self.cool.cooldown != None:
            if self.cool.cooldown > datetime.datetime.now().timestamp():
                failed_embed = discord.Embed(title="失敗", description="現在クールダウン中です、直近30秒以内に誰かが使用しました。", color=discord.Color.red())
                await interaction.response.send_message(embed=failed_embed, ephemeral=True)
                return
            
        self.cool.cooldown = datetime.datetime.now().timestamp() + 30

        processing_embed = discord.Embed(title="処理中", description="現在換金処理を行っております、このままお待ちください。", color=discord.Color.yellow())
        await interaction.response.send_message(embed=processing_embed, ephemeral=True)

        money_rate = self.config["exc_money_rate"]
        money_lite_rate = self.config["exc_money_lite_rate"]

        coro = asyncio.to_thread(self.paypay.check_link, self.paypay_link.value)
        response = await coro
        if response == None:
            error_embed = discord.Embed(title="エラー", description="リンクの情報を取得中にエラーが発生しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return
        
        with open("./data/paypay.json", "r", encoding="utf-8") as file:
            paypay_data = json.load(file)
        if paypay_data.get(str(interaction.user.id)) != response["payload"]["sender"]["externalId"]:
            failed_embed = discord.Embed(title="失敗", description="マネーロンダリング防止システムによって検知されました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=failed_embed)
            return
        
        money = response["payload"]["message"]["data"]["subWalletSplit"]["senderEmoneyAmount"]
        money_lite = response["payload"]["message"]["data"]["subWalletSplit"]["senderPrepaidAmount"]
        total = money + money_lite
        if total < self.config["exc_min_price"]:
            failed_embed = discord.Embed(title="失敗", description="最低換金額より小さいリンクは受付できません。", color=discord.Color.red())
            await interaction.edit_original_response(embed=failed_embed)
            return
        
        coro = asyncio.to_thread(self.stake.get_balance)
        balance = await coro
        if balance == None:
            error_embed = discord.Embed(title="エラー", description="現在の残高の取得に失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        coro = asyncio.to_thread(self.stake.get_rate)
        rate = await coro
        if rate == None:
            error_embed = discord.Embed(title="エラー", description="現在のコインのレート取得に失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        if int(balance*rate) < total:
            failed_embed = discord.Embed(title="失敗", description="換金額が残高を上回っています。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        _money = round(money * (money_rate / 100))
        _money_lite = round(money_lite * (money_lite_rate / 100))
        _total = _money + _money_lite

        coro = asyncio.to_thread(self.paypay.accept_link, self.paypay_link.value, None if self.paypay_passcode.value == "" else self.paypay_passcode.value)
        is_success = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー", description="PayPayリンクの受け取りに失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        coin_total = round(_total / rate, 8)
        
        coro = asyncio.to_thread(self.stake.send_tip, self.stake_id.value, coin_total)
        is_success, error_id = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー", description="チップの送金処理に失敗しました。", color=discord.Color.red())
            error_embed.add_field(name="エラーID", value=f"```\n{error_id}\n```", inline=False)
            await interaction.edit_original_response(embed=error_embed)
            return
        
        success_embed = discord.Embed(title="成功", description="換金処理に成功しました、数分以内にチップが届かない場合はエラーの可能性があります。", color=discord.Color.green())
        success_embed.add_field(name="受付済み", value=f"**マネー:** {money}円\n**マネラ:** {money_lite}円", inline=False)
        success_embed.add_field(name="換金済み", value=f"**マネー:** {_money}円\n**マネラ:** {_money_lite}円\n\n**合計:** {_total}円", inline=False)
        await interaction.edit_original_response(embed=success_embed)

        with open("./data/log.json", "r", encoding="utf-8") as file:
            log_data = json.load(file)
        if log_data.get(str(interaction.message.id)) == None:
            return
        
        log_embed = discord.Embed(title=f"換金ログ: {interaction.user.name}", description=f"**合計:** {total}円\n\n**Stake ID:** {self.stake_id.value}", color=discord.Color.random())
        log_channel = interaction.guild.get_channel(int(log_data[str(interaction.message.id)]))
        if log_channel == None:
            return
        await log_channel.send(embed=log_embed)

class AddressExchangeModal(discord.ui.Modal):
    def __init__(self, cool, config, paypay, stake, balance):
        super().__init__(
            title=f"残高: {balance}円",
            timeout=None
        )

        self.cool = cool
        self.config = config
        self.paypay = paypay
        self.stake = stake

        self.address = discord.ui.TextInput(
            label="LTC アドレス",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.address)

        self.paypay_link = discord.ui.TextInput(
            label="PayPay 送金リンク",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.paypay_link)

        self.paypay_passcode = discord.ui.TextInput(
            label="PayPay パスコード",
            style=discord.TextStyle.short,
            min_length=4,
            max_length=4,
            required=False
        )
        self.add_item(self.paypay_passcode)

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        if self.cool.cooldown != None:
            if self.cool.cooldown > datetime.datetime.now().timestamp():
                failed_embed = discord.Embed(title="失敗", description="現在クールダウン中です、直近30秒以内に誰かが使用しました。", color=discord.Color.red())
                await interaction.response.send_message(embed=failed_embed, ephemeral=True)
                return
            
        self.cool.cooldown = datetime.datetime.now().timestamp() + 30

        processing_embed = discord.Embed(title="処理中", description="現在換金処理を行っております、このままお待ちください。", color=discord.Color.yellow())
        await interaction.response.send_message(embed=processing_embed, ephemeral=True)

        money_rate = self.config["exc_money_rate"]
        money_lite_rate = self.config["exc_money_lite_rate"]

        coro = asyncio.to_thread(self.paypay.check_link, self.paypay_link.value)
        response = await coro
        if response == None:
            error_embed = discord.Embed(title="エラー", description="リンクの情報を取得中にエラーが発生しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return
        
        with open("./data/paypay.json", "r", encoding="utf-8") as file:
            paypay_data = json.load(file)
        if paypay_data.get(str(interaction.user.id)) != response["payload"]["sender"]["externalId"]:
            failed_embed = discord.Embed(title="失敗", description="マネーロンダリング防止システムによって検知されました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=failed_embed)
            return
        
        money = response["payload"]["message"]["data"]["subWalletSplit"]["senderEmoneyAmount"]
        money_lite = response["payload"]["message"]["data"]["subWalletSplit"]["senderPrepaidAmount"]
        total = money + money_lite
        if total < self.config["exc_min_price"]:
            failed_embed = discord.Embed(title="失敗", description="最低換金額より小さいリンクは受付できません。", color=discord.Color.red())
            await interaction.edit_original_response(embed=failed_embed)
            return
        
        coro = asyncio.to_thread(self.stake.get_balance)
        balance = await coro
        if balance == None:
            error_embed = discord.Embed(title="エラー", description="現在の残高の取得に失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        coro = asyncio.to_thread(self.stake.get_rate)
        rate = await coro
        if rate == None:
            error_embed = discord.Embed(title="エラー", description="現在のコインのレート取得に失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        if int(balance*rate) < total:
            failed_embed = discord.Embed(title="失敗", description="換金額が残高を上回っています。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        _money = round(money * (money_rate / 100))
        _money_lite = round(money_lite * (money_lite_rate / 100))
        _total = _money + _money_lite

        coro = asyncio.to_thread(self.paypay.accept_link, self.paypay_link.value, None if self.paypay_passcode.value == "" else self.paypay_passcode.value)
        is_success = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー", description="PayPayリンクの受け取りに失敗しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return

        coin_total = round(_total / rate, 8)
        
        coro = asyncio.to_thread(self.stake.withdraw_tip, self.address.value, coin_total)
        is_success, error_id = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー", description="コインの送金処理に失敗しました。", color=discord.Color.red())
            error_embed.add_field(name="エラーID", value=f"```\n{error_id}\n```", inline=False)
            await interaction.edit_original_response(embed=error_embed)
            return
        
        success_embed = discord.Embed(title="成功", description="換金処理に成功しました、数分以内に着金が検知されない場合エラーの可能性があります。", color=discord.Color.green())
        success_embed.add_field(name="注意", value="LTCには「Confirm」という作業があり、実際に残高に反映されるまで最大数時間かかります。\n焦らずお待ちください。", inline=False)
        success_embed.add_field(name="受付済み", value=f"**マネー:** {money}円\n**マネラ:** {money_lite}円", inline=False)
        success_embed.add_field(name="換金済み", value=f"**マネー:** {_money}円\n**マネラ:** {_money_lite}円\n\n**合計:** {_total}円", inline=False)
        await interaction.edit_original_response(embed=success_embed)

        with open("./data/log.json", "r", encoding="utf-8") as file:
            log_data = json.load(file)
        if log_data.get(str(interaction.message.id)) == None:
            return
        
        log_embed = discord.Embed(title=f"換金ログ: {interaction.user.name}", description=f"**マネー:** {money}円\n**マネラ:** {money_lite}円\n**合計:** {total}円\n\n**Address:** {self.address.value}", color=discord.Color.random())
        log_channel = interaction.guild.get_channel(int(log_data[str(interaction.message.id)]))
        if log_channel == None:
            return
        await log_channel.send(embed=log_embed)