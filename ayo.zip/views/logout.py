import json
import discord

class PayPayLogoutSelect(discord.ui.Select):
    def __init__(self):
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)
        
        options = []
        for ind, val in enumerate(cache_data["accounts"]):
            options.append(discord.SelectOption(label=f"アカウント{ind}", value=str(ind)))
        
        super().__init__(
            placeholder="アカウント選択",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(
        self,
        interaction: discord.Interaction
    ):
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)
        cache_data["accounts"].pop(int(self.values[0]))
        with open("./data/cache.json", "w", encoding="utf-8") as file:
            json.dump(cache_data, file, indent=4)

        success_embed = discord.Embed(title="成功", description="ログアウト処理に成功しました。", color=discord.Color.green())
        await interaction.response.send_message(embed=success_embed, ephemeral=True)

class PayPayLogoutSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(
            timeout=None
        )

        self.add_item(PayPayLogoutSelect())