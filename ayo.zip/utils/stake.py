import uuid
import pyotp
import datetime
import tls_client

class Stake:
    def __init__(self, access_token, tfa_token, user_agent, client_hints, cf_clearance, proxy, debug_mode):
        self.session = tls_client.Session(
            client_identifier="chrome_130",
            random_tls_extension_order=True
        )

        # Var
        self.access_token = access_token
        self.tfa_token = tfa_token
        self.user_agent = user_agent
        self.client_hints = client_hints
        self.cf_clearance = cf_clearance
        self.proxy = proxy
        self.debug_mode = debug_mode

    def get_rate(self):
        current_time = datetime.datetime.now()
        current_time_str = current_time.strftime('%Y/%m/%d-%H:%M:%S')

        try:
            response = self.session.post(
                "https://stake.com/_api/graphql",
                headers={
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Origin": "https://stake.com",
                    "Referer": "https://stake.com/",
                    "Sec-Ch-Ua": self.client_hints,
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "User-Agent": self.user_agent,
                    "X-Access-Token": self.access_token,
                    "X-Language": "ja"
                },
                json={
                    "query": "query CurrencyConversionRate {\n  info {\n    currencies {\n      name\n      eur: value(fiatCurrency: eur)\n      jpy: value(fiatCurrency: jpy)\n      usd: value(fiatCurrency: usd)\n      ars: value(fiatCurrency: ars)\n      brl: value(fiatCurrency: brl)\n      cad: value(fiatCurrency: cad)\n      clp: value(fiatCurrency: clp)\n      cny: value(fiatCurrency: cny)\n      dkk: value(fiatCurrency: dkk)\n      idr: value(fiatCurrency: idr)\n      inr: value(fiatCurrency: inr)\n      krw: value(fiatCurrency: krw)\n      mxn: value(fiatCurrency: mxn)\n      ngn: value(fiatCurrency: ngn)\n      pen: value(fiatCurrency: pen)\n      php: value(fiatCurrency: php)\n      pln: value(fiatCurrency: pln)\n      rub: value(fiatCurrency: rub)\n      try: value(fiatCurrency: try)\n      vnd: value(fiatCurrency: vnd)\n    }\n  }\n}\n",
                    "variables": {}
                },
                cookies={
                    "cf_clearance": self.cf_clearance
                },
                proxy=self.proxy
            ).json()
        except:
            print(f"Stake | Time: {current_time_str} | Method: GET RATE | Type: ERROR | Response: NULL | Reason: CLOUDFLARE BLOCKED")
            return None

        for rate in response["data"]["info"]["currencies"]:
            if rate["name"] == "ltc":
                if self.debug_mode:
                    print(f"Stake | Time: {current_time_str} | Method: GET RATE | Type: SUCCESS | Response: {response} | Reason: NULL")
                else:
                    print(f"Stake | Time: {current_time_str} | Method: GET RATE | Type: SUCCESS | Response: OMITTED | Reason: NULL")
                return rate["jpy"]
        
        if self.debug_mode:
            print(f"Stake | Time: {current_time_str} | Method: GET RATE | Type: ERROR | Response: {response} | Reason: ELEMENT NOT FOUND")
        else:
            print(f"Stake | Time: {current_time_str} | Method: GET RATE | Type: ERROR | Response: OMITTED | Reason: ELEMENT NOT FOUND")

        return None
    
    def get_balance(self):
        current_time = datetime.datetime.now()
        current_time_str = current_time.strftime('%Y/%m/%d-%H:%M:%S')

        try:
            response = self.session.post(
                "https://stake.com/_api/graphql",
                headers={
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Origin": "https://stake.com",
                    "Referer": "https://stake.com/",
                    "Sec-Ch-Ua": self.client_hints,
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "User-Agent": self.user_agent,
                    "X-Access-Token": self.access_token,
                    "X-Language": "ja"
                },
                json={
                    "operationName": "UserBalances",
                    "query": "query UserBalances {\n  user {\n    id\n    balances {\n      available {\n        amount\n        currency\n        __typename\n      }\n      vault {\n        amount\n        currency\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n"
                },
                cookies={
                    "cf_clearance": self.cf_clearance
                },
                proxy=self.proxy
            ).json()
        except:
            print(f"Stake | Time: {current_time_str} | Method: GET BALANCE | Type: ERROR | Response: NULL | Reason: CLOUDFLARE BLOCKED")
            return None

        for balance in response["data"]["user"]["balances"]:
            if balance["available"]["currency"] == "ltc":
                if self.debug_mode:
                    print(f"Stake | Time: {current_time_str} | Method: GET BALANCE | Type: SUCCESS | Response: {response} | Reason: NULL")
                else:
                    print(f"Stake | Time: {current_time_str} | Method: GET BALANCE | Type: SUCCESS | Response: OMITTED | Reason: NULL")
                return balance["available"]["amount"]
        
        if self.debug_mode:
            print(f"Stake | Time: {current_time_str} | Method: GET BALANCE | Type: ERROR | Response: {response} | Reason: ELEMENT NOT FOUND")
        else:
            print(f"Stake | Time: {current_time_str} | Method: GET BALANCE | Type: ERROR | Response: OMITTED | Reason: ELEMENT NOT FOUND")

        return None
    
    def send_tip(self, stake_id, amount):
        current_time = datetime.datetime.now()
        current_time_str = current_time.strftime('%Y/%m/%d-%H:%M:%S')

        error_id = str(uuid.uuid4())

        try:
            response = self.session.post(
                "https://stake.com/_api/graphql",
                headers={
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Origin": "https://stake.com",
                    "Referer": "https://stake.com/",
                    "Sec-Ch-Ua": self.client_hints,
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "User-Agent": self.user_agent,
                    "X-Access-Token": self.access_token,
                    "X-Language": "ja"
                },
                json={
                    "operationName": "SendTipMeta",
                    "query": "query SendTipMeta($name: String) {\n  user(name: $name) {\n    id\n    name\n    __typename\n  }\n  self: user {\n    id\n    hasTfaEnabled\n    isTfaSessionValid\n    balances {\n      available {\n        amount\n        currency\n        __typename\n      }\n      vault {\n        amount\n        currency\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n",
                    "variables": {
                        "name": stake_id
                    }
                },
                cookies={
                    "cf_clearance": self.cf_clearance
                },
                proxy=self.proxy
            ).json()
        except:
            print(f"Stake | Time: {current_time_str} | Method: SEND TIP - GET META | Type: ERROR({error_id}) | Response: NULL | Reason: CLOUDFLARE BLOCKED")
            return False, error_id
        
        if response["data"]["user"] == None:
            if self.debug_mode:
                print(f"Stake | Time: {current_time_str} | Method: SENT TIP - GET META | Type: ERROR({error_id}) | Response: {response} | Reason: USER NOT FOUND")
            else:
                print(f"Stake | Time: {current_time_str} | Method: SENT TIP - GET META | Type: ERROR({error_id}) | Response: OMITTED | Reason: USER NOT FOUND")
            return False, error_id
        
        if self.debug_mode:
            print(f"Stake | Time: {current_time_str} | Method: SENT TIP - GET META | Type: SUCCESS | Response: {response} | Reason: NULL")
        else:
            print(f"Stake | Time: {current_time_str} | Method: SENT TIP - GET META | Type: SUCCESS | Response: OMITTED | Reason: NULL")
        
        stake_user_id = response["data"]["user"]["id"]
        totp = pyotp.TOTP(self.tfa_token)

        try:
            self.session.post(
                "https://stake.com/_api/graphql",
                headers={
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Origin": "https://stake.com",
                    "Referer": "https://stake.com/",
                    "Sec-Ch-Ua": self.client_hints,
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "User-Agent": self.user_agent,
                    "X-Access-Token": self.access_token,
                    "X-Language": "ja"
                },
                json={
                    "operationName": "SendTip",
                    "query": "mutation SendTip($userId: String!, $amount: Float!, $currency: CurrencyEnum!, $isPublic: Boolean, $chatId: String!, $tfaToken: String) {\n  sendTip(\n    userId: $userId\n    amount: $amount\n    currency: $currency\n    isPublic: $isPublic\n    chatId: $chatId\n    tfaToken: $tfaToken\n  ) {\n    id\n    amount\n    currency\n    user {\n      id\n      name\n      __typename\n    }\n    sendBy {\n      id\n      name\n      balances {\n        available {\n          amount\n          currency\n          __typename\n        }\n        vault {\n          amount\n          currency\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n",
                    "variables": {
                        "userId": stake_user_id,
                        "amount": amount,
                        "currency": "ltc",
                        "isPublic": False,
                        "chatId": "c65b4f32-0001-4e1d-9cd6-e4b3538b43ae",
                        "tfaToken": totp.now()
                    }
                },
                cookies={
                    "cf_clearance": self.cf_clearance
                },
                proxy=self.proxy
            ).json()
        except:
            print(f"Stake | Time: {current_time_str} | Method: SEND TIP | Type: ERROR({error_id}) | Response: NULL | Reason: CLOUDFLARE BLOCKED")
            return False, error_id
        
        errors = response.get("errors")
        if errors != None:
            message = errors[0]["message"]
            if self.debug_mode:
                print(f"Stake | Time: {current_time_str} | Method: SEND TIP | Type: ERROR({error_id}) | Response: {response} | Reason: {message}")
            else:
                print(f"Stake | Time: {current_time_str} | Method: SEND TIP | Type: ERROR({error_id}) | Response: OMITTED | Reason: {message}")
            return False, error_id
        
        if self.debug_mode:
            print(f"Stake | Time: {current_time_str} | Method: SEND TIP | Type: SUCCESS | Response: {response} | Reason: NULL")
        else:
            print(f"Stake | Time: {current_time_str} | Method: SEND TIP | Type: SUCCESS | Response: OMITTED | Reason: NULL")

        return True, None
    
    def withdraw_tip(self, address, amount):
        current_time = datetime.datetime.now()
        current_time_str = current_time.strftime('%Y/%m/%d-%H:%M:%S')

        error_id = str(uuid.uuid4())

        query = """
            mutation CreateWithdrawal($chain: CryptoChainEnum, $currency: CryptoCurrencyEnum!, $address: String!, $amount: Float!, $emailCode: String, $tfaToken: String, $oauthToken: String) {
                createWithdrawal(
                    chain: $chain
                    currency: $currency
                    address: $address
                    amount: $amount
                    emailCode: $emailCode
                    tfaToken: $tfaToken
                    oauthToken: $oauthToken
                ) {
                    id
                }
            }
        """

        totp = pyotp.TOTP(self.tfa_token)

        try:
            response = self.session.post(
                "https://stake.com/_api/graphql",
                headers={
                    "Accept": "*/*",
                    "Content-Type": "application/json",
                    "Origin": "https://stake.com",
                    "Referer": "https://stake.com/",
                    "Sec-Ch-Ua": self.client_hints,
                    "Sec-Ch-Ua-Mobile": "?0",
                    "Sec-Ch-Ua-Platform": '"Windows"',
                    "User-Agent": self.user_agent,
                    "X-Access-Token": self.access_token,
                    "X-Language": "ja"
                },
                json={
                    "query": query,
                    "variables": {
                        "currency": "ltc",
                        "address": address,
                        "amount": amount,
                        "chain": None,
                        "tfaToken": totp.now()
                    }
                },
                cookies={
                    "cf_clearance": self.cf_clearance
                },
                proxy=self.proxy
            ).json()
        except:
            print(f"Stake | Time: {current_time_str} | Method: WITHDRAW TIP | Type: ERROR({error_id}) | Response: NULL | Reason: CLOUDFLARE BLOCKED")
            return False, error_id
        
        errors = response.get("errors")
        if errors != None:
            message = errors[0]["message"]
            if self.debug_mode:
                print(f"Stake | Time: {current_time_str} | Method: WITHDRAW TIP | Type: ERROR({error_id}) | Response: {response} | Reason: {message}")
            else:
                print(f"Stake | Time: {current_time_str} | Method: WITHDRAW TIP | Type: ERROR({error_id}) | Response: OMITTED | Reason: {message}")
            return False, error_id

        if self.debug_mode:
            print(f"Stake | Time: {current_time_str} | Method: WITHDRAW TIP | Type: SUCCESS | Response: {response} | Reason: NULL")
        else:
            print(f"Stake | Time: {current_time_str} | Method: WITHDRAW TIP | Type: SUCCESS | Response: OMITTED | Reason: NULL")

        return True, None