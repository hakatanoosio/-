import os
import json
import uuid
import discord
import asyncio

from utils.paypay import PayPay

class PayPayLoginStartModal(discord.ui.Modal):
    def __init__(self, account_index):
        super().__init__(
            title="PayPayログイン - 資格情報",
            timeout=None
        )

        self.account_index = account_index

        self.phone = discord.ui.TextInput(
            label="電話番号 (ハイフン無し)",
            style=discord.TextStyle.short,
            min_length=11,
            max_length=11,
            required=True
        )
        self.add_item(self.phone)

        self.password = discord.ui.TextInput(
            label="パスワード",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.password)

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)

        try:
            account_cache = cache_data["accounts"][self.account_index]
        except:
            account_cache = {
                "device_uuid": str(uuid.uuid4()),
                "client_uuid": str(uuid.uuid4())
            }

        device_uuid = account_cache["device_uuid"]
        client_uuid = account_cache["client_uuid"]

        paypay = PayPay(device_uuid=device_uuid, client_uuid=client_uuid)

        processing_embed = discord.Embed(title="処理中 - OTP送信中", description="現在ログイン処理を実行中です、お待ちください。", color=discord.Color.yellow())
        await interaction.response.send_message(embed=processing_embed, ephemeral=True)
        
        coro = asyncio.to_thread(paypay.login_start, self.phone.value, self.password.value)
        is_success = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー - OTP送信失敗", description="PayPayへのログイン処理中にエラーが発生しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed, ephemeral=True)
            return
        
        if paypay.access_token != None:
            with open("./data/cache.json", "r", encoding="utf-8") as file:
                cache_data = json.load(file)

            try:
                cache_data["accounts"][self.account_index]["access_token"] = paypay.access_token
            except:
                cache_data["accounts"].append({
                    "access_token": paypay.access_token,
                    "device_uuid": device_uuid,
                    "client_uuid": client_uuid
                })

            with open("./data/cache.json", "w", encoding="utf-8") as file:
                json.dump(cache_data, file, indent=4)

            success_embed = discord.Embed(title="成功 - ログイン済み", description="PayPayへのログインに成功しました。", color=discord.Color.green())
            await interaction.edit_original_response(embed=success_embed)
            return
        
        success_embed = discord.Embed(title="成功 - OTP送信済み", description="OTPの送信に成功しました、SMSでURLを受信したらボタンを押して続行してください。", color=discord.Color.green())
        await interaction.edit_original_response(embed=success_embed, view=PayPayLoginOTPButton(self.account_index, paypay))
        
class PayPayLoginOTPButton(discord.ui.View):
    def __init__(self, account_index, paypay):
        super().__init__(
            timeout=None
        )

        self.account_index = account_index
        self.paypay = paypay

    @discord.ui.button(
        label="OTP認証",
        style=discord.ButtonStyle.green
    )
    async def otp_verify(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button
    ):
        await interaction.response.send_modal(PayPayLoginOTPModal(self.account_index, self.paypay))

class PayPayLoginOTPModal(discord.ui.Modal):
    def __init__(self, account_index, paypay):
        super().__init__(
            title="PayPayログイン - OTP",
            timeout=None
        )

        self.account_index = account_index
        self.paypay = paypay

        self.url = discord.ui.TextInput(
            label="URL",
            style=discord.TextStyle.short,
            required=True
        )
        self.add_item(self.url)

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        processing_embed = discord.Embed(title="処理中 - ログイン中", description="現在ログイン処理を実行中です、お待ちください。", color=discord.Color.yellow())
        await interaction.response.edit_message(embed=processing_embed, view=None)

        coro = asyncio.to_thread(self.paypay.login_confirm, self.url.value)
        is_success = await coro
        if not is_success:
            error_embed = discord.Embed(title="エラー - ログイン失敗", description="PayPayへのログイン処理中にエラーが発生しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return
        
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)

        try:
            cache_data["accounts"][self.account_index]["access_token"] = self.paypay.access_token
        except:
            cache_data["accounts"].append({
                "access_token": self.paypay.access_token,
                "device_uuid": self.paypay.device_uuid,
                "client_uuid": self.paypay.client_uuid
            })
        
        with open("./data/cache.json", "w", encoding="utf-8") as file:
            json.dump(cache_data, file, indent=4)

        success_embed = discord.Embed(title="成功 - ログイン済み", description="PayPayへのログインに成功しました。", color=discord.Color.green())
        await interaction.edit_original_response(embed=success_embed)
        return
    
class PayPayRelogSelect(discord.ui.Select):
    def __init__(self):
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)
        
        options = []
        for ind, val in enumerate(cache_data["accounts"]):
            options.append(discord.SelectOption(label=f"アカウント{ind}", value=str(ind)))
        
        super().__init__(
            placeholder="アカウント選択",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(
        self,
        interaction: discord.Interaction
    ):
        await interaction.response.send_modal(PayPayLoginStartModal(int(self.values[0])))

class PayPayRelogSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(
            timeout=None
        )

        self.add_item(PayPayRelogSelect())