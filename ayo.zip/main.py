import yaml
import json
import discord
from discord.ext import commands  # ← ここ！上の方に置く！
import time

from typing import Optional
from discord import app_commands

from views.exchange import ExchangeButton
from views.logout import PayPayLogoutSelectView
from views.login import PayPayLoginStartModal, PayPayRelogSelectView

client = discord.Client(intents=discord.Intents.all())
tree = app_commands.CommandTree(client)

with open("config.yml", "r", encoding="utf-8") as file:
    config = yaml.safe_load(file)

class Cooldown:
    cooldown = None

cool = Cooldown()

class PayPayGroup(app_commands.Group):
    pass
paypay_group = PayPayGroup(name="paypay")

class LinkGroup(app_commands.Group):
    pass
link_group = LinkGroup(name="link")

@client.event
async def on_ready():
    client.add_view(ExchangeButton(cool, config))

    tree.add_command(paypay_group)
    tree.add_command(link_group)

    await tree.sync()

    print("Logged In")

@tree.command(
    name="panel",
    description="換金パネルを設置します"
)
async def panel(
    interaction: discord.Interaction,
    log_channel: Optional[discord.TextChannel],
    embed_title: Optional[str],
    embed_description: Optional[str]
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return
    
    await interaction.response.defer(ephemeral=True)
    
    money_rate = config["exc_money_rate"]
    money_lite_rate = config["exc_money_lite_rate"]
    minimum_exchange_price = config["exc_min_price"]

    panel_embed = discord.Embed(title="LTC換金" if embed_title == None else embed_title, description="PayPayからLTCへ換金を行うことができます。" if embed_description == None else embed_description, color=discord.Color.magenta())
    panel_embed.add_field(name="換金率", value=f"**マネー:** {money_rate}%\n**マネラ:** {money_lite_rate}%", inline=False)
    panel_embed.add_field(name="最低換金額", value=f"{minimum_exchange_price}円", inline=False)
    panel_message = await interaction.channel.send(embed=panel_embed, view=ExchangeButton(cool, config))

    if log_channel != None:
        with open("./data/log.json", "r", encoding="utf-8") as file:
            log_data = json.load(file)
        log_data[str(panel_message.id)] = str(log_channel.id)
        with open("./data/log.json", "w", encoding="utf-8") as file:
            json.dump(log_data, file, indent=4)

    success_embed = discord.Embed(title="成功", description="換金パネルを設置しました。", color=discord.Color.green())
    await interaction.followup.send(embed=success_embed)

@paypay_group.command(
    name="login",
    description="PayPayへログインを実行します"
)
async def paypay_login(
    interaction: discord.Interaction
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return
    
    await interaction.response.send_modal(PayPayLoginStartModal(99))

@paypay_group.command(
    name="relog",
    description="PayPayへログインを実行します"
)
async def paypay_relog(
    interaction: discord.Interaction
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return
    
    relog_embed = discord.Embed(title="アカウント選択", description="該当するリログするPayPayアカウントを選択してください。", color=discord.Color.red())
    await interaction.response.send_message(embed=relog_embed, view=PayPayRelogSelectView())

@paypay_group.command(
    name="logout",
    description="PayPayからのログアウトを行います"
)
async def paypay_logout(
    interaction: discord.Interaction
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return
    
    logout_embed = discord.Embed(title="アカウント選択", description="該当するログアウトするPayPayアカウントを選択してください。", color=discord.Color.red())
    await interaction.response.send_message(embed=logout_embed, view=PayPayLogoutSelectView())

@link_group.command(
    name="set",
    description="PayPayの登録を手動で行います"
)
async def link_set(
    interaction: discord.Interaction,
    discord_user: discord.Member,
    paypay_user: str
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return

    with open("./data/paypay.json", "r", encoding="utf-8") as file:
        paypay_data = json.load(file)
    paypay_data[str(discord_user.id)] = paypay_user
    with open("./data/paypay.json", "w", encoding="utf-8") as file:
        json.dump(paypay_data, file, indent=4)

    success_embed = discord.Embed(title="成功", description="PayPayの手動登録に成功しました。", color=discord.Color.green())
    await interaction.response.send_message(embed=success_embed, ephemeral=True)

@link_group.command(
    name="del",
    description="PayPayの登録を手動で解除します"
)
async def link_set(
    interaction: discord.Interaction,
    discord_user: discord.Member
):
    if config["discord_owner"] != interaction.user.id:
        failed_embed = discord.Embed(title="失敗", description="Botのオーナー以外はコマンドを使用することができません。", color=discord.Color.red())
        await interaction.response.send_message(embed=failed_embed, ephemeral=True)
        return

    with open("./data/paypay.json", "r", encoding="utf-8") as file:
        paypay_data = json.load(file)
    paypay_data.remove(discord_user.id)
    with open("./data/paypay.json", "w", encoding="utf-8") as file:
        json.dump(paypay_data, file, indent=4)

    success_embed = discord.Embed(title="成功", description="PayPayの手動解除に成功しました。", color=discord.Color.green())
    await interaction.response.send_message(embed=success_embed, ephemeral=True)

client.run(config["discord_token"])


intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.tree.command(name="ping", description="Botの接続状況を確認します。")
async def ping(interaction: discord.Interaction):
    start_time = time.time()
    await interaction.response.send_message("🏓 Pinging...", ephemeral=True)
    end_time = time.time()

    latency_ms = round((end_time - start_time) * 1000)
    heartbeat_ms = round(bot.latency * 1000)

    await interaction.edit_original_response(
        content=f"✅ Pong!\n- WebSocket Latency: `{heartbeat_ms}ms`\n- REST API Latency: `{latency_ms}ms`"
    )

@bot.event
async def on_ready():
    # 🔥 スラッシュコマンドをDiscordに登録
    synced = await bot.tree.sync()
    print(f"✅ Logged in as {bot.user}")
    print(f"✅ Synced {len(synced)} slash commands")

@bot.command()
async def ping(ctx):
    start_time = time.time()
    msg = await ctx.send("🏓 Pinging...")
    end_time = time.time()
    latency_ms = round((end_time - start_time) * 1000)
    heartbeat_ms = round(bot.latency * 1000)
    await msg.edit(content=f"✅ Pong!\n- WS: `{heartbeat_ms}ms`\n- REST: `{latency_ms}ms`")
