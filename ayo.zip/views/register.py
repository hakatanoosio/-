import os
import json
import random
import discord
import asyncio

from utils.paypay import PayPay

class StartRegisterModal(discord.ui.Modal):
    def __init__(self):
        self.price = random.randint(1, 100)

        super().__init__(
            title=f"初回登録: {self.price}円",
            timeout=None
        )

        self.paypay_link = discord.ui.TextInput(
            label="送金リンク",
            style=discord.TextStyle.short,
            placeholder="リンクは受け取られません",
            required=True
        )
        self.add_item(self.paypay_link)

    async def on_submit(
        self,
        interaction: discord.Interaction
    ):
        if not os.path.isfile("./data/cache.json"):
            error_embed = discord.Embed(title="エラー", description="PayPayにログインされていません。", color=discord.Color.red())
            await interaction.response.send_message(embed=error_embed, ephemeral=True)
            return
        
        with open("./data/cache.json", "r", encoding="utf-8") as file:
            cache_data = json.load(file)
        max_index = len(cache_data["accounts"]) - 1
        min_index = 0
        acc_index = random.randint(min_index, max_index)
        account_cache = cache_data["accounts"][acc_index]

        processing_embed = discord.Embed(title="処理中", description="現在登録処理中です、このままお待ちください。", color=discord.Color.yellow())
        await interaction.response.send_message(embed=processing_embed, ephemeral=True)

        paypay = PayPay(account_cache["access_token"], account_cache["device_uuid"], account_cache["client_uuid"])
        
        coro = asyncio.to_thread(paypay.check_link, self.paypay_link.value)
        response = await coro
        if response == None:
            error_embed = discord.Embed(title="エラー", description="リンクの情報を取得中にエラーが発生しました。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return
        
        if self.price != response["payload"]["pendingP2PInfo"]["amount"]:
            error_embed = discord.Embed(title="エラー", description="リンクの金額が登録金額と一致しません。", color=discord.Color.red())
            await interaction.edit_original_response(embed=error_embed)
            return
        
        with open("./data/paypay.json", "r", encoding="utf-8") as file:
            paypay_data = json.load(file)
        paypay_data[str(interaction.user.id)] = response["payload"]["sender"]["externalId"]
        with open("./data/paypay.json", "w", encoding="utf-8") as file:
            json.dump(paypay_data, file, indent=4)

        success_embed = discord.Embed(title="成功", description="PayPayの登録処理が完了しました。", color=discord.Color.green())
        await interaction.edit_original_response(embed=success_embed)